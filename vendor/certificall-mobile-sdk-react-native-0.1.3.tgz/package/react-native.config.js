module.exports = {
  dependency: {
    platforms: {
      android: {
        packageImportPath: 'import com.certificall.reactnative.CertificallTrustPackage;',
        packageInstance: 'new CertificallTrustPackage()',
      },
    },
  },
};

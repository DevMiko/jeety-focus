import { NativeModules, NativeEventEmitter, type EmitterSubscription } from 'react-native';

const NativeModule =
  NativeModules.CertificallTrust ??
  NativeModules.CertificallTrustModule;

if (!NativeModule) {
  throw new Error(
    'CertificallTrust native module is not linked. Rebuild iOS/Android app after installing pods.'
  );
}

const eventEmitter = new NativeEventEmitter(NativeModule);

export type ConnectionType = 'wifi' | 'cellular' | 'none' | 'unknown';

export interface DeviceInfo {
  manufacturer: string;
  model: string;
  os: string;
  osVersion: string;
  isEmulator: boolean;
  name?: string;
  uuid?: string;
  platform?: 'ios' | 'android';
  webViewVersion?: string;
  memUsed?: number;
  diskFree?: number;
  diskTotal?: number;
}

export interface LocationCoords {
  latitude: number;
  longitude: number;
  accuracy: number;
  altitude: number | null;
  speed: number | null;
  heading: number | null;
}

export interface LocationPosition {
  coords: LocationCoords;
  timestamp: number;
}

export interface MotionData {
  acceleration: { x: number; y: number; z: number };
  rotationRate: { alpha: number; beta: number; gamma: number };
  timestamp?: number;
}

export interface DeviceSnapshotOptions {
  includeLocation?: boolean;
  includeMotion?: boolean;
}

export interface DeviceSnapshot {
  device: DeviceInfo;
  location?: LocationPosition;
  motion?: MotionData;
  devMode?: { enabled: boolean };
  timestamp: number;
}

export interface WatchSubscription {
  remove: () => void;
}

export interface PhotoOptions {
  reportToken?: string;
  metadata?: Record<string, string | number | boolean>;
}

export interface ConfigureOptions {
  apiKey: string;
  baseUrl?: string;
  appVersion?: string;
  debugMode?: boolean;
}

export interface CertifiedPhotoResult {
  itemId?: string;
  caseId?: string;
  score?: number;
}

export const CertificallTrust = {
  configure: (options: ConfigureOptions): Promise<void> => NativeModule.configure(options),

  // Device (getDeviceInfo & getBatteryStatus are internal, used by snapshot)
  getNetworkStatus: (): Promise<{ connected: boolean; connectionType: ConnectionType }> =>
    NativeModule.getNetworkStatus(),

  startNetworkMonitoring: (callback: (status: { connected: boolean; connectionType: ConnectionType }) => void): WatchSubscription => {
    const subscription: EmitterSubscription = eventEmitter.addListener('networkStatusChange', callback);
    NativeModule.startNetworkMonitoring();
    return {
      remove: () => {
        subscription.remove();
        NativeModule.stopNetworkMonitoring();
      },
    };
  },

  // Location
  getCurrentPosition: (): Promise<LocationPosition> => NativeModule.getCurrentPosition(),

  watchPosition: (callback: (position: LocationPosition) => void): WatchSubscription => {
    const subscription: EmitterSubscription = eventEmitter.addListener('watchPosition', callback);
    NativeModule.watchPosition();
    return {
      remove: () => {
        subscription.remove();
        NativeModule.stopWatchPosition();
      },
    };
  },

  // Motion
  getCurrentMotion: (): Promise<MotionData> => NativeModule.getCurrentMotion(),

  watchMotion: (callback: (motion: MotionData) => void): WatchSubscription => {
    const subscription: EmitterSubscription = eventEmitter.addListener('watchMotion', callback);
    NativeModule.watchMotion();
    return {
      remove: () => {
        subscription.remove();
        NativeModule.stopWatchMotion();
      },
    };
  },

  // Camera (certified photo flow)
  takePhoto: (options?: PhotoOptions): Promise<CertifiedPhotoResult> =>
    NativeModule.takePhoto(options ?? {}),

  requestCameraPermission: (): Promise<boolean> =>
    NativeModule.requestCameraPermission(),

  requestLocationPermission: (): Promise<string> =>
    NativeModule.requestLocationPermission(),

  requestMotionPermission: (): Promise<boolean> =>
    NativeModule.requestMotionPermission(),

  // Snapshot
  getDeviceSnapshot: (options?: DeviceSnapshotOptions): Promise<DeviceSnapshot> =>
    NativeModule.getDeviceSnapshot(options ?? {}),
};


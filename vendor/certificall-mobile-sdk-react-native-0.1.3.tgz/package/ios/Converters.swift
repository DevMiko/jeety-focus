import Foundation
import CertificallTrust

// Same toDictionary() extensions as Capacitor bridge
// Both use [String: Any] dictionaries for native → JS conversion

extension BatteryStatus {
    func toDictionary() -> [String: Any] {
        return ["level": level, "isCharging": isCharging]
    }
}

extension DeviceInfo {
    func toDictionary() -> [String: Any] {
        return [
            "manufacturer": manufacturer,
            "model": model,
            "os": os,
            "osVersion": osVersion,
            "isEmulator": isEmulator,
            "name": name,
            "uuid": uuid,
            "platform": platform,
            "webViewVersion": webViewVersion,
            "memUsed": memUsed,
            "diskFree": diskFree,
            "diskTotal": diskTotal
        ]
    }
}

extension NetworkStatus {
    func toDictionary() -> [String: Any] {
        return ["connected": connected, "connectionType": connectionType]
    }
}

extension LocationData {
    func toDictionary() -> [String: Any] {
        return [
            "coords": [
                "latitude": latitude,
                "longitude": longitude,
                "accuracy": accuracy,
                "altitude": altitude,
                "speed": speed,
                "heading": heading
            ],
            "timestamp": timestamp
        ]
    }
}

extension MotionData {
    func toDictionary() -> [String: Any] {
        return [
            "acceleration": ["x": x, "y": y, "z": z],
            "rotationRate": ["alpha": gyroX, "beta": gyroY, "gamma": gyroZ],
            "timestamp": timestamp
        ]
    }
}

extension DeveloperModeStatus {
    func toDictionary() -> [String: Any] {
        return ["enabled": enabled]
    }
}

extension DeviceSnapshot {
    func toDictionary() -> [String: Any] {
        var deviceDict = device.toDictionary()
        deviceDict["batteryLevel"] = battery.level
        deviceDict["isCharging"] = battery.isCharging
        deviceDict["connectionType"] = network.connectionType

        var dict: [String: Any] = [
            "device": deviceDict,
            "timestamp": timestamp,
            "devMode": ["enabled": false]
        ]
        if let location = location {
            dict["location"] = location.toDictionary()
        }
        if let motion = motion {
            dict["motion"] = motion.toDictionary()
        }
        return dict
    }
}

extension ExifData {
    func toDictionary() -> [String: Any] {
        var dict: [String: Any] = [:]
        if let latitude = latitude { dict["latitude"] = latitude }
        if let longitude = longitude { dict["longitude"] = longitude }
        if let altitude = altitude { dict["altitude"] = altitude }
        if let dateTimeOriginal = dateTimeOriginal { dict["dateTimeOriginal"] = dateTimeOriginal }
        if let width = width { dict["width"] = width }
        if let height = height { dict["height"] = height }
        if let orientation = orientation { dict["orientation"] = orientation }
        if let make = make { dict["make"] = make }
        if let model = model { dict["model"] = model }
        if let exposureTime = exposureTime { dict["exposureTime"] = exposureTime }
        if let fNumber = fNumber { dict["fNumber"] = fNumber }
        if let iso = iso { dict["iso"] = iso }
        if let focalLength = focalLength { dict["focalLength"] = focalLength }
        if let flash = flash { dict["flash"] = flash }
        return dict
    }
}

extension PhotoResult {
    func toDictionary() -> [String: Any] {
        var dict: [String: Any] = [
            "format": format,
            "width": width,
            "height": height
        ]
        if let base64 = base64 { dict["base64"] = base64 }
        if let exif = exif { dict["exif"] = exif.toDictionary() }
        return dict
    }
}


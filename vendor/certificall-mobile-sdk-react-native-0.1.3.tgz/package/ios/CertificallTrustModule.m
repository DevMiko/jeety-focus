#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>

@interface RCT_EXTERN_REMAP_MODULE(CertificallTrust, CertificallTrustModule, RCTEventEmitter)

// Configuration
RCT_EXTERN_METHOD(configure:(NSDictionary *)options resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)

// Device (getDeviceInfo & getBatteryStatus are internal)
RCT_EXTERN_METHOD(getNetworkStatus:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(startNetworkMonitoring:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(stopNetworkMonitoring:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)

// Location
RCT_EXTERN_METHOD(getCurrentPosition:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(watchPosition:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(stopWatchPosition:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)

// Motion
RCT_EXTERN_METHOD(getCurrentMotion:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(watchMotion:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(stopWatchMotion:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)

// Snapshot
RCT_EXTERN_METHOD(getDeviceSnapshot:(NSDictionary *)options resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)

// Camera
RCT_EXTERN_METHOD(takePhoto:(NSDictionary *)options resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)

// Permissions
RCT_EXTERN_METHOD(requestCameraPermission:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(requestLocationPermission:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(requestMotionPermission:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)

@end

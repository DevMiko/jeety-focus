import Foundation
import UIKit
import React
import CertificallTrust

@objc(CertificallTrustModule)
class CertificallTrustModule: RCTEventEmitter {

    private let sdk = CertificallTrustSDK()

    override static func requiresMainQueueSetup() -> Bool { false }

    override func supportedEvents() -> [String]! {
        return ["watchPosition", "watchMotion", "networkStatusChange"]
    }

    // MARK: - Configuration

    @objc func configure(_ options: NSDictionary,
                         resolve: @escaping RCTPromiseResolveBlock,
                         reject: @escaping RCTPromiseRejectBlock) {
        guard let apiKey = options["apiKey"] as? String, !apiKey.isEmpty else {
            reject("CONFIG_ERROR", "apiKey is required", nil)
            return
        }
        let baseUrl = options["baseUrl"] as? String ?? "https://admin.certificall.app/certificall/"
        let appVersion = options["appVersion"] as? String ?? "1.0.0"
        sdk.configure(apiKey: apiKey, baseUrl: baseUrl, appVersion: appVersion)
        resolve(nil)
    }

    // MARK: - Device (getDeviceInfo & getBatteryStatus are internal, used by snapshot)

    @objc func getNetworkStatus(_ resolve: @escaping RCTPromiseResolveBlock,
                                reject: @escaping RCTPromiseRejectBlock) {
        resolve(sdk.getNetworkStatus().toDictionary())
    }

    @objc func startNetworkMonitoring(_ resolve: @escaping RCTPromiseResolveBlock,
                                      reject: @escaping RCTPromiseRejectBlock) {
        sdk.startNetworkMonitoring { [weak self] status in
            self?.sendEvent(withName: "networkStatusChange", body: status.toDictionary())
        }
        resolve(nil)
    }

    @objc func stopNetworkMonitoring(_ resolve: @escaping RCTPromiseResolveBlock,
                                     reject: @escaping RCTPromiseRejectBlock) {
        sdk.stopNetworkMonitoring()
        resolve(nil)
    }

    // MARK: - Location

    @objc func getCurrentPosition(_ resolve: @escaping RCTPromiseResolveBlock,
                                  reject: @escaping RCTPromiseRejectBlock) {
        sdk.getCurrentPosition { location, error in
            if let error = error {
                reject("LOCATION_ERROR", error.localizedDescription, error)
                return
            }
            if let location = location {
                resolve(location.toDictionary())
            } else {
                reject("LOCATION_ERROR", "No location data", nil)
            }
        }
    }

    @objc func watchPosition(_ resolve: @escaping RCTPromiseResolveBlock,
                             reject: @escaping RCTPromiseRejectBlock) {
        sdk.watchPosition { [weak self] location in
            self?.sendEvent(withName: "watchPosition", body: location.toDictionary())
        }
        resolve(nil)
    }

    @objc func stopWatchPosition(_ resolve: @escaping RCTPromiseResolveBlock,
                                 reject: @escaping RCTPromiseRejectBlock) {
        sdk.stopWatchPosition()
        resolve(nil)
    }

    // MARK: - Motion

    @objc func getCurrentMotion(_ resolve: @escaping RCTPromiseResolveBlock,
                                reject: @escaping RCTPromiseRejectBlock) {
        resolve(sdk.getCurrentMotion().toDictionary())
    }

    @objc func watchMotion(_ resolve: @escaping RCTPromiseResolveBlock,
                           reject: @escaping RCTPromiseRejectBlock) {
        sdk.watchMotion { [weak self] motion in
            self?.sendEvent(withName: "watchMotion", body: motion.toDictionary())
        }
        resolve(nil)
    }

    @objc func stopWatchMotion(_ resolve: @escaping RCTPromiseResolveBlock,
                               reject: @escaping RCTPromiseRejectBlock) {
        sdk.stopWatchMotion()
        resolve(nil)
    }

    // MARK: - Snapshot

    @objc func getDeviceSnapshot(_ options: NSDictionary,
                                 resolve: @escaping RCTPromiseResolveBlock,
                                 reject: @escaping RCTPromiseRejectBlock) {
        let includeLocation = options["includeLocation"] as? Bool ?? false
        let includeMotion = options["includeMotion"] as? Bool ?? false

        sdk.getDeviceSnapshot(
            includeLocation: includeLocation,
            includeMotion: includeMotion
        ) { snapshot in
            resolve(snapshot.toDictionary())
        }
    }

    // MARK: - Camera

    @objc func takePhoto(_ options: NSDictionary,
                         resolve: @escaping RCTPromiseResolveBlock,
                         reject: @escaping RCTPromiseRejectBlock) {
        let reportToken = options["reportToken"] as? String
        let metadata = options["metadata"] as? [String: Any]

        Task { @MainActor [weak self] in
            guard let self = self else { return }
            guard let vc = UIApplication.shared.delegate?.window??.rootViewController else {
                reject("CAMERA_ERROR", "No view controller available", nil)
                return
            }

            self.sdk.takePhoto(from: vc, reportToken: reportToken, metadata: metadata) { itemId, caseId, score, error in
                if let error = error {
                    reject("CAMERA_ERROR", error.localizedDescription, error)
                    return
                }
                resolve([
                    "itemId": itemId as Any,
                    "caseId": caseId as Any,
                    "score": score as Any
                ])
            }
        }
    }

    // MARK: - Permissions

    @objc func requestCameraPermission(_ resolve: @escaping RCTPromiseResolveBlock,
                                       reject: @escaping RCTPromiseRejectBlock) {
        sdk.requestCameraPermission { granted in
            resolve(granted)
        }
    }

    @objc func requestLocationPermission(_ resolve: @escaping RCTPromiseResolveBlock,
                                         reject: @escaping RCTPromiseRejectBlock) {
        sdk.requestLocationPermission { status in
            resolve(status)
        }
    }

    @objc func requestMotionPermission(_ resolve: @escaping RCTPromiseResolveBlock,
                                       reject: @escaping RCTPromiseRejectBlock) {
        sdk.requestMotionPermission()
        resolve(true)
    }
}

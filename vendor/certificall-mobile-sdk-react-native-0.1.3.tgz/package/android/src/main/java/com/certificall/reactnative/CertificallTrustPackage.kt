package com.certificall.reactnative

import com.facebook.react.BaseReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.module.model.ReactModuleInfo
import com.facebook.react.module.model.ReactModuleInfoProvider
import java.util.HashMap

/**
 * Enregistre [CertificallTrustModule] via [BaseReactPackage] (API recommandee RN 0.81+,
 * evite la deprecation de [com.facebook.react.ReactPackage.createNativeModules]).
 */
class CertificallTrustPackage : BaseReactPackage() {

    override fun getModule(name: String, reactContext: ReactApplicationContext): NativeModule? {
        return if (name == MODULE_NAME) {
            CertificallTrustModule(reactContext)
        } else {
            null
        }
    }

    override fun getReactModuleInfoProvider(): ReactModuleInfoProvider {
        val infos = HashMap<String, ReactModuleInfo>(1)
        infos[MODULE_NAME] = ReactModuleInfo(
            MODULE_NAME,
            CertificallTrustModule::class.java.name,
            false,
            false,
            false,
            false,
        )
        return ReactModuleInfoProvider { infos }
    }

    private companion object {
        const val MODULE_NAME = "CertificallTrust"
    }
}

package com.certificall.reactnative

import app.certificall.sdk.models.*
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.WritableMap

internal fun DeviceInfo.toWritableMap(): WritableMap {
    val map = Arguments.createMap()
    map.putString("manufacturer", manufacturer)
    map.putString("model", model)
    map.putString("os", os)
    map.putString("osVersion", osVersion)
    map.putBoolean("isEmulator", isEmulator)
    map.putString("name", name)
    map.putString("uuid", uuid)
    map.putString("platform", platform)
    map.putString("webViewVersion", webViewVersion)
    map.putDouble("memUsed", memUsed.toDouble())
    map.putDouble("diskFree", diskFree.toDouble())
    map.putDouble("diskTotal", diskTotal.toDouble())
    return map
}

internal fun BatteryStatus.toWritableMap(): WritableMap {
    val map = Arguments.createMap()
    map.putDouble("level", level)
    map.putBoolean("isCharging", isCharging)
    return map
}

internal fun NetworkStatus.toWritableMap(): WritableMap {
    val map = Arguments.createMap()
    map.putBoolean("connected", connected)
    map.putString("connectionType", connectionType)
    return map
}

internal fun LocationData.toWritableMap(): WritableMap {
    val map = Arguments.createMap()
    val coords = Arguments.createMap()
    coords.putDouble("latitude", latitude)
    coords.putDouble("longitude", longitude)
    coords.putDouble("accuracy", accuracy)
    coords.putDouble("altitude", altitude)
    coords.putDouble("speed", speed)
    coords.putDouble("heading", heading)
    map.putMap("coords", coords)
    map.putDouble("timestamp", timestamp.toDouble())
    return map
}

internal fun MotionData.toWritableMap(): WritableMap {
    val map = Arguments.createMap()
    val acceleration = Arguments.createMap()
    acceleration.putDouble("x", x)
    acceleration.putDouble("y", y)
    acceleration.putDouble("z", z)
    val rotationRate = Arguments.createMap()
    rotationRate.putDouble("alpha", gyroX)
    rotationRate.putDouble("beta", gyroY)
    rotationRate.putDouble("gamma", gyroZ)
    map.putMap("acceleration", acceleration)
    map.putMap("rotationRate", rotationRate)
    map.putDouble("timestamp", timestamp.toDouble())
    return map
}

internal fun DeviceSnapshot.toWritableMap(): WritableMap {
    val map = Arguments.createMap()

    val deviceMap = device.toWritableMap()
    deviceMap.putDouble("batteryLevel", battery.level)
    deviceMap.putBoolean("isCharging", battery.isCharging)
    deviceMap.putString("connectionType", network.connectionType)
    map.putMap("device", deviceMap)

    map.putDouble("timestamp", timestamp.toDouble())

    val devMode = Arguments.createMap()
    devMode.putBoolean("enabled", false)
    map.putMap("devMode", devMode)

    if (location != null) {
        map.putMap("location", location!!.toWritableMap())
    }
    if (motion != null) {
        map.putMap("motion", motion!!.toWritableMap())
    }
    return map
}

internal fun ExifData.toWritableMap(): WritableMap {
    val map = Arguments.createMap()
    latitude?.let { map.putDouble("latitude", it) }
    longitude?.let { map.putDouble("longitude", it) }
    altitude?.let { map.putDouble("altitude", it) }
    dateTimeOriginal?.let { map.putString("dateTimeOriginal", it) }
    width?.let { map.putInt("width", it) }
    height?.let { map.putInt("height", it) }
    orientation?.let { map.putInt("orientation", it) }
    make?.let { map.putString("make", it) }
    model?.let { map.putString("model", it) }
    exposureTime?.let { map.putDouble("exposureTime", it) }
    fNumber?.let { map.putDouble("fNumber", it) }
    iso?.let { map.putInt("iso", it) }
    focalLength?.let { map.putDouble("focalLength", it) }
    flash?.let { map.putBoolean("flash", it) }
    return map
}

internal fun PhotoResult.toWritableMap(): WritableMap {
    val map = Arguments.createMap()
    base64?.let { map.putString("base64", it) }
    map.putString("format", format)
    map.putInt("width", width)
    map.putInt("height", height)
    exif?.let { map.putMap("exif", it.toWritableMap()) }
    return map
}


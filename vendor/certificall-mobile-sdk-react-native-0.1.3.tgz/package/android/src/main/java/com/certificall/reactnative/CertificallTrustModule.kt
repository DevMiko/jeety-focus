package com.certificall.reactnative

import app.certificall.sdk.CertificallTrustSDK
import android.app.Activity
import android.content.Intent
import android.util.Log
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ActivityEventListener
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.ReadableType
import com.facebook.react.modules.core.DeviceEventManagerModule

class CertificallTrustModule(
    private val reactContext: ReactApplicationContext
) : ReactContextBaseJavaModule(reactContext), ActivityEventListener {

    private val sdk = CertificallTrustSDK(reactContext)

    init {
        reactContext.addActivityEventListener(this)
    }

    override fun getName() = "CertificallTrust"

    override fun onActivityResult(activity: Activity, requestCode: Int, resultCode: Int, data: Intent?) {
        Log.d("CertificallRN", "Forwarding activity result to SDK (requestCode=$requestCode, resultCode=$resultCode)")
        sdk.handleActivityResult(activity, requestCode, resultCode, data)
    }

    override fun onNewIntent(intent: Intent) {
        // Not used for camera flow.
    }

    private fun sendEvent(name: String, params: Any?) {
        reactContext
            .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            .emit(name, params)
    }

    // region Device (getDeviceInfo & getBatteryStatus are internal, used by snapshot)

    @ReactMethod
    fun configure(options: ReadableMap, promise: Promise) {
        val apiKey = if (options.hasKey("apiKey")) options.getString("apiKey") else null
        if (apiKey.isNullOrBlank()) {
            promise.reject("CONFIG_ERROR", "apiKey is required")
            return
        }
        val baseUrl = if (options.hasKey("baseUrl")) options.getString("baseUrl") else "https://admin.certificall.app/certificall/"
        val appVersion = if (options.hasKey("appVersion")) options.getString("appVersion") else "1.0.0"
        val debugMode = options.hasKey("debugMode") && options.getBoolean("debugMode")
        sdk.configure(
            apiKey,
            baseUrl ?: "https://admin.certificall.app/certificall/",
            appVersion ?: "1.0.0",
            debugMode
        )
        promise.resolve(null)
    }

    @ReactMethod
    fun getNetworkStatus(promise: Promise) {
        promise.resolve(sdk.getNetworkStatus().toWritableMap())
    }

    @ReactMethod
    fun startNetworkMonitoring(promise: Promise) {
        sdk.startNetworkMonitoring { status ->
            sendEvent("networkStatusChange", status.toWritableMap())
        }
        promise.resolve(null)
    }

    @ReactMethod
    fun stopNetworkMonitoring(promise: Promise) {
        sdk.stopNetworkMonitoring()
        promise.resolve(null)
    }

    // endregion

    // region Location

    @ReactMethod
    fun getCurrentPosition(promise: Promise) {
        sdk.getCurrentPosition { location, error ->
            if (error != null) {
                promise.reject("LOCATION_ERROR", error.message, error)
                return@getCurrentPosition
            }
            if (location != null) {
                promise.resolve(location.toWritableMap())
            } else {
                promise.reject("LOCATION_ERROR", "No location data")
            }
        }
    }

    @ReactMethod
    fun watchPosition(promise: Promise) {
        sdk.watchPosition { location ->
            sendEvent("watchPosition", location.toWritableMap())
        }
        promise.resolve(null)
    }

    @ReactMethod
    fun stopWatchPosition(promise: Promise) {
        sdk.stopWatchPosition()
        promise.resolve(null)
    }

    // endregion

    // region Motion

    @ReactMethod
    fun getCurrentMotion(promise: Promise) {
        sdk.getCurrentMotion { motion, error ->
            if (error != null) {
                promise.reject("MOTION_ERROR", error.message, error)
                return@getCurrentMotion
            }
            if (motion != null) {
                promise.resolve(motion.toWritableMap())
            } else {
                promise.reject("MOTION_ERROR", "No motion data")
            }
        }
    }

    @ReactMethod
    fun watchMotion(promise: Promise) {
        sdk.watchMotion { motion ->
            sendEvent("watchMotion", motion.toWritableMap())
        }
        promise.resolve(null)
    }

    @ReactMethod
    fun stopWatchMotion(promise: Promise) {
        sdk.stopWatchMotion()
        promise.resolve(null)
    }

    // endregion

    // region Snapshot

    @ReactMethod
    fun getDeviceSnapshot(options: ReadableMap, promise: Promise) {
        val includeLocation = options.hasKey("includeLocation") && options.getBoolean("includeLocation")
        val includeMotion = options.hasKey("includeMotion") && options.getBoolean("includeMotion")

        sdk.getDeviceSnapshot(includeLocation, includeMotion) { snapshot, error ->
            if (snapshot != null) {
                promise.resolve(snapshot.toWritableMap())
            } else {
                promise.reject("SNAPSHOT_ERROR", error?.message ?: "Snapshot failed")
            }
        }
    }

    // endregion

    // region Camera

    @ReactMethod
    fun takePhoto(options: ReadableMap, promise: Promise) {
        val reportToken = if (options.hasKey("reportToken")) options.getString("reportToken") else null
        val metadataMap = if (options.hasKey("metadata") && options.getType("metadata") == ReadableType.Map) {
            options.getMap("metadata")?.let { readableMapToMap(it) }
        } else {
            null
        }

        val activity = reactApplicationContext.currentActivity
        if (activity == null) {
            promise.reject("CAMERA_ERROR", "No activity available")
            return
        }

        sdk.takePhoto(activity, reportToken, metadataMap) { itemId, caseId, score, error ->
            if (error != null) {
                promise.reject("CAMERA_ERROR", error.message ?: "Certified photo failed")
            } else {
                val map = com.facebook.react.bridge.Arguments.createMap()
                map.putString("itemId", itemId)
                map.putString("caseId", caseId)
                if (score != null) {
                    map.putDouble("score", score)
                } else {
                    map.putNull("score")
                }
                promise.resolve(map)
            }
        }
    }

    // endregion

    // Required for NativeEventEmitter
    @ReactMethod
    fun addListener(eventName: String) {}

    @ReactMethod
    fun removeListeners(count: Int) {}

    private fun readableMapToMap(readableMap: ReadableMap): Map<String, Any> {
        val result = mutableMapOf<String, Any>()
        val iterator = readableMap.keySetIterator()
        while (iterator.hasNextKey()) {
            val key = iterator.nextKey()
            when (readableMap.getType(key)) {
                ReadableType.String -> readableMap.getString(key)?.let { result[key] = it }
                ReadableType.Number -> result[key] = readableMap.getDouble(key)
                ReadableType.Boolean -> result[key] = readableMap.getBoolean(key)
                else -> {}
            }
        }
        return result
    }
}

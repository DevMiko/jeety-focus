# Certificall React Native SDK

Ce package expose le SDK natif Certificall (iOS + Android) pour React Native via `NativeModules`.
Ce README est oriente developpement interne (repo source SDK).

## Prerequis

- React Native `>= 0.72`
- iOS: Xcode + CocoaPods
- Android: Android Studio + SDK 24+
- Node 18+

`Expo Go` n'est **pas** supporte (module natif requis).

## Installation

```bash
npm install certificall-mobile-sdk-react-native
```

Puis rebuild natif:

```bash
# iOS
cd ios && pod install && cd ..

# Android (depuis la racine RN)
npx react-native run-android
```

### Installation locale (monorepo)

```json
{
  "dependencies": {
    "certificall-mobile-sdk-react-native": "file:../../react-native"
  }
}
```

## iOS

Ajoutez le pod dans votre `ios/Podfile` (si autolink non actif):

```ruby
pod "CertificallTrustRN", :path => "../certificall-mobile-sdk"
```

Puis:

```bash
cd ios
pod install
```

Permissions `Info.plist` minimales:

```xml
<key>NSCameraUsageDescription</key>
<string>Camera access is required for certified photo capture.</string>
<key>NSLocationWhenInUseUsageDescription</key>
<string>Location is required for trust validation.</string>
<key>NSMotionUsageDescription</key>
<string>Motion sensors are required for trust validation.</string>
```

## Android

Si l'autolinking ne detecte pas le module, ajoutez manuellement le package dans `MainApplication.kt`:

```kotlin
import com.certificall.reactnative.CertificallTrustPackage

override fun getPackages(): List<ReactPackage> =
  PackageList(this).packages.apply {
    add(CertificallTrustPackage())
  }
```

Permissions `AndroidManifest.xml` minimales:

```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```

## Utilisation

```ts
import { CertificallTrust } from 'certificall-mobile-sdk-react-native';

await CertificallTrust.configure({
  apiKey: 'YOUR_API_KEY',
  baseUrl: 'https://admin.certificall.app/certificall/',
  appVersion: '0.1.1',
});

await CertificallTrust.requestCameraPermission();
await CertificallTrust.requestLocationPermission();
await CertificallTrust.requestMotionPermission();

const result = await CertificallTrust.takePhoto({
  reportToken: 'REPORT_456',
  metadata: { flow: 'rn-example' },
});
```

## API exposee

- `configure(options)`
- `takePhoto(options)`
- `requestCameraPermission()`
- `requestLocationPermission()`
- `requestMotionPermission()`

## Troubleshooting

- **No such module 'PackageDescription'**: assurez-vous que `sdk/ios/Package.swift` n'est pas compile comme source iOS par CocoaPods (il doit etre exclu du podspec).
- **Package doesn't seem to be linked**: verifier `pod install`, rebuild complet, et que vous n'utilisez pas Expo Go.
- **Android missing native module**: verifier autolinking ou ajout manuel de `CertificallTrustPackage`.
- **Permissions refusees**: demander explicitement la permission camera/localisation cote app avant appel aux APIs qui en dependent.

---
Certificall.

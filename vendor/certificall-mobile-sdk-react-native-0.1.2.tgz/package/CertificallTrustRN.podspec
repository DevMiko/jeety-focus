require 'json'

package = JSON.parse(File.read(File.join(__dir__, 'package.json')))

Pod::Spec.new do |s|
  s.name = 'CertificallTrustRN'
  s.version = package['version']
  s.summary = package['description']
  s.license = package['license']
  s.homepage = package['repository']['url']
  s.author = package['author']
  s.source = { :git => package['repository']['url'], :tag => s.version.to_s }
  s.source_files = ['ios/**/*.{swift,m,h}']
  s.preserve_paths = ['ios/CertificallTrust.xcframework']
  s.vendored_frameworks = ['ios/CertificallTrust.xcframework']
  s.ios.deployment_target = '13.0'
  s.dependency 'React-Core'
  s.swift_version = '5.1'
end

# Certificall React Native SDK (Delivery)

Ce package expose le SDK natif Certificall (iOS + Android) pour React Native via `NativeModules`.
Il est distribue depuis le repo de livraison client.
Ce README est oriente integration client externe.

## Prerequis

- React Native `>= 0.72`
- iOS: Xcode + CocoaPods
- Android: Android Studio + SDK 24+
- Node 18+

`Expo Go` n'est **pas** supporte (module natif requis).

## Matrice de compatibilite

- React Native: `>= 0.72`
- Expo: workflow prebuild/dev build uniquement (`expo run:ios` / `expo run:android`)
- Xcode: `>= 15`
- iOS deployment target: `13.0`
- Android SDK min: `24`

## Contraintes runtime connues

- `Expo Go` non supporte (module natif requis).
- Le premier build iOS sur device peut exiger une configuration manuelle de la signature.
- Pour les flux camera/senseurs, preferer un device physique plutot qu'un emulateur.

## Installation

Le package est consomme depuis le repo de delivery (non publie sur npm public).

```bash
npm install ../certificall-mobile-sdk-delivery/react-native
```

Puis rebuild natif:

```bash
# iOS
cd ios && pod install && cd ..

# Android (depuis la racine RN)
npx react-native run-android
```

### Installation locale (monorepo)

```json
{
  "dependencies": {
    "certificall-mobile-sdk-react-native": "file:../certificall-mobile-sdk-delivery/react-native"
  }
}
```

## iOS

Ajoutez le pod dans votre `ios/Podfile` (si autolink non actif):

```ruby
pod "CertificallTrustRN", :path => "../certificall-mobile-sdk-delivery"
```

Puis:

```bash
cd ios
pod install
```

Permissions `Info.plist` minimales:

```xml
<key>NSCameraUsageDescription</key>
<string>Camera access is required for certified photo capture.</string>
<key>NSLocationWhenInUseUsageDescription</key>
<string>Location is required for trust validation.</string>
<key>NSMotionUsageDescription</key>
<string>Motion sensors are required for trust validation.</string>
```

## Android

Si l'autolinking ne detecte pas le module, ajoutez manuellement le package dans `MainApplication.kt`:

```kotlin
import com.certificall.reactnative.CertificallTrustPackage

override fun getPackages(): List<ReactPackage> =
  PackageList(this).packages.apply {
    add(CertificallTrustPackage())
  }
```

Permissions `AndroidManifest.xml` minimales:

```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```

## Utilisation

```ts
import { CertificallTrust } from 'certificall-mobile-sdk-react-native';

await CertificallTrust.configure({
  apiKey: 'YOUR_API_KEY',
  baseUrl: 'https://admin.certificall.app/certificall/',
  appVersion: '0.1.0',
});

await CertificallTrust.requestCameraPermission();
await CertificallTrust.requestLocationPermission();
await CertificallTrust.requestMotionPermission();

const result = await CertificallTrust.takePhoto({
  reportToken: 'REPORT_456',
  metadata: { flow: 'rn-example' },
});
```

## API exposee

- `configure(options)`
- `takePhoto(options)`
- `requestCameraPermission()`
- `requestLocationPermission()`
- `requestMotionPermission()`

## Troubleshooting

- **No such module 'PackageDescription'**: assurez-vous que `sdk/ios/Package.swift` n'est pas compile comme source iOS par CocoaPods (il doit etre exclu du podspec).
- **Package doesn't seem to be linked**: verifier `pod install`, rebuild complet, et que vous n'utilisez pas Expo Go.
- **Android missing native module**: verifier autolinking ou ajout manuel de `CertificallTrustPackage`.
- **Permissions refusees**: demander explicitement la permission camera/localisation cote app avant appel aux APIs qui en dependent.

---
Certificall.

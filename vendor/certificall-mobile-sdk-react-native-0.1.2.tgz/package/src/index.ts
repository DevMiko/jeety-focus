import { NativeModules } from 'react-native';

const NativeModule =
  NativeModules.CertificallTrust ??
  NativeModules.CertificallTrustModule;

if (!NativeModule) {
  throw new Error(
    'CertificallTrust native module is not linked. Rebuild iOS/Android app after installing pods.'
  );
}

export interface PhotoOptions {
  reportToken?: string;
  metadata?: Record<string, string | number | boolean>;
}

export interface ConfigureOptions {
  apiKey: string;
  baseUrl?: string;
  appVersion?: string;
  debugMode?: boolean;
}

export interface CertifiedPhotoResult {
  itemId?: string;
  caseId?: string;
  score?: number;
}

export const CertificallTrust = {
  configure: (options: ConfigureOptions): Promise<void> => NativeModule.configure(options),
  takePhoto: (options?: PhotoOptions): Promise<CertifiedPhotoResult> =>
    NativeModule.takePhoto(options ?? {}),

  requestCameraPermission: (): Promise<boolean> =>
    NativeModule.requestCameraPermission(),

  requestLocationPermission: (): Promise<string> =>
    NativeModule.requestLocationPermission(),

  requestMotionPermission: (): Promise<boolean> =>
    NativeModule.requestMotionPermission(),
};

